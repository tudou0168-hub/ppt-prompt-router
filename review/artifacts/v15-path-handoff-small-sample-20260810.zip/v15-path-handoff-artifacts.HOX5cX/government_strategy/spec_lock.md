<!-- ppt-master-schema: spec-lock/v1 -->
# Execution Lock

## canvas
- viewBox: 0 0 1280 720
- format: PPT 16:9

## communication
- primary_language: zh-Hans-CN
- audience: 县政府领导与项目决策部门
- objective: 说明规划的事实边界与总体体系，推动领导确认建设范围、协同条件与后续实施保障。
- core_message: 规划方向可作为建设共识，但需先核实底数、确认边界并统筹数据、网点与组织保障，方可形成可执行实施方案。
- consumption_mode: balanced

## mode
- mode: pyramid

## visual_style
- visual_style: swiss-minimal

## colors
- background: #F7F8FA
- secondary_background: #E9EEF5
- primary: #0B3A6D
- accent: #C83D2A
- secondary_accent: #5A7D5C
- body_text: #162230

## typography
- font_family: Microsoft YaHei, Arial, sans-serif
- title_family: Microsoft YaHei, Arial, sans-serif
- body_family: Microsoft YaHei, Arial, sans-serif
- body: 24
- title: 42
- subtitle: 32
- lead: 30
- annotation: 18
- footnote: 16

## icons
- library: none
- inventory: none

## page_rhythm
- P01: anchor
- P02: dense
- P03: dense
- P04: breathing
- P05: dense
- P06: anchor
- P07: dense
- P08: dense
- P09: dense
- P10: dense
- P11: breathing
- P12: breathing
- P13: dense
- P14: anchor
- P15: anchor

## pptx_structure
- mode: flat

## forbidden
- `mask`, `<style>`, `class`, external CSS, `<foreignObject>`, `textPath`, `@font-face`, `<animate*>`, `<set>`, `<script>` / event attributes, `<iframe>`
- HTML named entities in text; write typography as raw Unicode and escape XML reserved characters
