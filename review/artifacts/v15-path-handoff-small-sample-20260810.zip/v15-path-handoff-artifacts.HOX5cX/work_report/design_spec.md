<!-- ppt-master-schema: design-spec/v1 -->
# v15-work-report_ppt169_20260810 - Design Spec

## I. Project Information

| Item | Value |
| --- | --- |
| Project Name | v15-work-report_ppt169_20260810 |
| Canvas Format | PPT 16:9 (1280 × 720) |
| Page Count | 8 |
| Primary Language | zh-CN |
| Target Audience | 新郑市云瀚大数据运营发展有限公司项目负责人及交付管理层 |
| Communication Intent | 在客户月度复盘会上，以已填写且可追溯的报告记录说明服务范围、阶段结果、系统运行、风险和行动；同时明确不能据此下结论的证据缺口。 |
| Desired Audience Outcome | 客户与交付团队能够确认本次复盘区间和服务范围，识别需要补齐的运行、事件、工单与需求证据，并在会后形成协同输入与闭环台账。 |
| Core Message / Ask / Action | 可确认的记录包括 3 个应用系统“运行良好”和 1 项 22.0h、已完成的需求；尚不能将空白、`xx`或模板文字视为运营成效，需先完成数据核验与协同补证。 |
| Delivery Context | 客户项目月度复盘会，现场讲解并留作后续跟踪依据。 |
| Artifact Afterlife | 会后作为复盘口径、风险问题与协同事项的工作底稿。 |
| Reading Mode | balanced |
| Content Strategy | 严格沿用已确认的 8 页策划顺序与事实边界；原始报告中空白字段、`xx`、示例文字、待补附件和未填写表格均只可作为“证据缺口”说明，不可被包装为服务结果。 |
| Design Style | 数据新闻式客户运维复盘：纸张浅底、细规则、状态颜色与证据侧栏，强调可审阅性。 |
| Formula Policy | text-only |
| AI Image Acquisition Path | not applicable |
| Generation Mode | continuous |
| Spec Refinement | disabled |
| Speaker Notes | disabled — delegated Stage-2 sample decision; 本轮只进行四页视觉样本与质量检查。 |
| Custom Animations | disabled — final Stage-2 proactive policy for this static review sample. |
| Narration Audio | disabled — final Stage-2 proactive policy. |
| Created Date | 2026-08-10 |

## II. Canvas Specification

| Property | Value |
| --- | --- |
| Format | PPT 16:9 |
| Dimensions | 1280 × 720 |
| viewBox | `0 0 1280 720` |
| Margins | 48px outer safe margin |
| Content Area | 1184 × 600px beneath a 72px title band |

## III. Visual Theme

### Theme Style

- **Mode**: briefing
- **Visual style**: data-journalism
- **Theme**: 可追溯的运维事实簿——用冷静的蓝灰主色承载已核实记录，以琥珀和红色将“待核验”与“风险缺口”显式分层。
- **Tone**: 克制、专业、可审阅；结果不夸大，风险不渲染。

### Color Scheme

| Role | HEX | Purpose |
| --- | --- | --- |
| Background | #F7F8FA | 纸张感浅底 |
| Secondary background | #E9EEF3 | 表格带、侧栏与弱信息面 |
| Primary | #123B5D | 标题、主规则与已核实事实 |
| Accent | #007C91 | 已核实状态与关键证据强调 |
| Secondary accent | #C98500 | 待核验、待确认与注意事项 |
| Body text | #1D2730 | 正文与表格主文字 |

## IV. Typography System

### Font Plan

| Role | Character (Reference) | Primary | English if non-English | Fallback tail |
| --- | --- | --- | --- | --- |
| Title | 权威、清晰的无衬线标题 | Microsoft YaHei | Arial | sans-serif |
| Body | 中性、紧凑的业务阅读文字 | Microsoft YaHei | Arial | sans-serif |

- **Title stack**: Microsoft YaHei, Arial, sans-serif
- **Body stack**: Microsoft YaHei, Arial, sans-serif

### Font Size Hierarchy

| Purpose | Anchor Size (px) |
| --- | ---: |
| Body | 24 |
| Title | 42 |
| Subtitle | 30 |
| Annotation | 18 |
| Footnote | 16 |
| Data | 22 |

## V. Layout Principles

### Page Structure

- **Header area**: 左对齐页码、主题标签与主题标题；标题下用一条主色细规则固定阅读起点。
- **Content area**: 以 12 列编辑网格组织主结论、证据明细和右侧“口径/风险”侧栏；不使用装饰性大图。
- **Footer area**: 标注“资料来源：阶段性服务报告已填写内容”或“建议协同项”，并保留页码。

### Spacing Specification

| Element | Current Project |
| --- | --- |
| Safe margin | 48px |
| Content block gap | 20px |
| Icon-text gap | 10px |

## VI. Icon Usage Specification

- **Primary bundled library**: none

| Icon Path | Suitable Scenarios |
| --- | --- |

## VIII. Image Resource List

| Filename | Dimensions | Ratio | Purpose | Type | Layout pattern | Crop Policy | Acquire Via | Status | Reference | text_policy | page_role |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

## IX. Content Outline

### Part 1: 复盘边界与事实基础

#### Slide 01 - 本次复盘：覆盖期、项目与事实口径

- **Audience move**: 从将材料默认理解为单月结论，转为先确认阶段报告与本次月度复盘的边界。
- **Layout**: 以覆盖期时间轴为页面钩子；左侧放项目与合同事实，右侧用“阶段报告 ≠ 已确认单月口径”的注释带形成必要停顿。
- **Title**: 本次复盘：先对齐覆盖期与月度口径
- **Core message**: 报告覆盖 2025-12-17 至 2026-03-17，未标明本次复盘对应的单月区间。
- **Content**: 项目“新郑市智慧城市综合应用业务系统建设项目”；客户单位“新郑市云瀚大数据运营发展有限公司”；服务商“新点（报告落款：国泰新点软件股份有限公司）”；合同编号“A2023120424”；报告日期“2026 年 3 月 24 日”。在时间轴后明确提出：请客户确认本次会议复盘整段覆盖期，还是仅复盘其中某一自然月。
- **Cover impact**: 以覆盖期时间线与醒目的“阶段报告 / 月度复盘”口径对照建立全场事实边界；构图可由 Executor 调整。

#### Slide 02 - 阶段结果与证据完整度

- **Audience move**: 从只关注结果，转为同时识别已核实记录与尚未形成结论的运营证据缺口。
- **Layout**: 非对称双栏。左侧以“已核实记录”主栏呈现 3 个应用运行状态与 1 项需求交付；右侧窄栏以琥珀色列出不能形成结论的统计维度，底部放事实边界注释。
- **Title**: 阶段结果与证据完整度
- **Core message**: 现有材料可确认 3 个应用“运行良好”及 1 项需求“已完成”；服务范围、巡检、工单等关键运营数据仍不完整。
- **Content**: 主结论带：“已核实：3 个应用运行记录 + 1 项已完成需求”。应用运行记录：一件事服务系统、政务服务事项精细化梳理工具、证明在线开具，均登记“运行良好”，运行日志检查也均登记“运行良好”。需求记录：合同内“预填表功能设计-移动端”，工时 22.0h，完成情况“已完成”。证据缺口：服务器资产与性能、运维工单数量、现场咨询、巡检次数与预警、处理率、重大问题次数缺少已填写项目数据或仅有模板占位。页脚说明：空白、`xx`及示例文字不计为业绩数据。
- **Visualization**: 自定义“已核实记录 / 待补关键证据”双栏证据地图；由来源表的状态和已填写字段决定文本，不使用虚构比例。

#### Slide 03 - 本期服务范围：已见模块与待确认边界

- **Audience move**: 从以报告目录代替实际范围，转为区分服务维度与已存在的本期明细证据。
- **Layout**: 上方一条服务维度带，底部采用“已有具体明细 / 待双方确认”两区，对应资料来源并列标示。
- **Title**: 本期服务范围：已见模块与待确认边界
- **Core message**: 报告框架覆盖多类运维服务，但已形成可核验明细的仅为 1 项需求优化和 3 个应用运行记录。
- **Content**: 列出报告服务维度：需求优化、系统问题处理、运维工单、现场技术咨询、平台环境巡检与处理、系统及设备运行情况。已有具体明细：需求优化“预填表功能设计-移动端”22.0h、已完成；应用运行 3 个系统均登记运行良好。待确认：服务器、数据库、工单、现场咨询、巡检及预警的实际服务范围与数量。

### Part 2: 可核实结果与风险边界

#### Slide 04 - 系统运行：3 个应用均登记为运行良好

- **Audience move**: 从笼统理解“系统稳定”，转为明确这是应用层和日志检查的登记状态，不能扩大为全栈性能结论。
- **Layout**: 主区为三行状态表，右侧为基础设施证据边界说明；状态颜色只编码报告登记结果。
- **Title**: 系统运行：3 个应用均登记为运行良好
- **Core message**: 三个应用在运行态势和运行日志检查中均登记“运行良好”；服务器、数据库与性能数据未提供。
- **Content**: 三行表：一件事服务系统 / 运行良好 / 运行良好；政务服务事项精细化梳理工具 / 运行良好 / 运行良好；证明在线开具 / 运行良好 / 运行良好。边界说明：主要设备状况注明“见附件；需将自动生成的服务器信息手动添加”，附件和服务器信息未随材料提供；不展示服务器数量、资源利用率或性能结论。
- **Native-ready**: no

#### Slide 05 - 需求交付：已完成 1 项移动端预填表功能设计

- **Audience move**: 从将一条历史登记直接视为本期成果，转为先核验交付归属与汇总口径。
- **Layout**: 左侧为单条需求的纵向交付记录卡，突出“22.0h / 已完成”；右侧为两条时间和数量一致性校验带，使用琥珀色风险标记。
- **Title**: 需求交付：已完成 1 项移动端预填表功能设计
- **Core message**: 唯一已填写的需求明细登记为已完成、22.0h；其时间归属和汇总数量仍需核验。
- **Content**: 需求名称：预填表功能设计-移动端；需求类型：合同内；登记日期：2024-11-06；工时：22.0h；完成情况：已完成。复盘前核验一：原报告叙述该需求为“本期内”处理，但登记日期早于 2025-12-17，请确认实际完成/验收时间及本期归属。复盘前核验二：维护情况统计表填列“需求数量 3（个）”，需求明细仅列 1 项，请确认缺失的 2 项或更正汇总。说明：未提供验收记录、上线时间、业务收益、用户反馈或功能截图，不推导业务价值结论。
- **Visualization**: 自定义“交付记录 → 时间归属核验 → 明细/汇总核验”证据链；不以箭头暗示已完成本期验收。

#### Slide 06 - 问题与运行风险：当前主要风险是运营数据缺口

- **Audience move**: 从“未记录问题”推断“没有风险”，转为将缺失的运行证据视为需要管理闭环的首要风险。
- **Layout**: 左上方为现有问题/事件记录摘录，右侧为“不能据此证明无风险”的边界提示，底部以四项证据缺口构成风险清单和纠偏方向。
- **Title**: 问题与运行风险：当前主要风险是运营数据缺口
- **Core message**: 系统问题处理表登记 0 项、重大事件表未填记录，但巡检、资产和事件明细缺失，不能据此证明不存在运行风险。
- **Content**: 现有记录：系统问题处理表登记 0 项、0h，未列问题明细；重大事件/故障表只有表头，未提供事件记录。风险判断边界：上述内容不能单独证明本期无故障或无运行风险。需补证据：服务器/数据库资产清单与巡检记录；监控或日志证据；事件起止时间、原因和处置记录；工单及关闭状态。建议纠偏：建立按月汇总、按事项留痕、按风险闭环的运行台账。注：巡检模板中“0 次、0 台”与“需手动添加服务器信息”并存，不视为实际资产或巡检统计。
- **Visualization**: 自定义“问题记录—证据缺口—管理风险”三段式证据链；用风险色仅标记待补的验证项。

### Part 3: 行动与客户协同

#### Slide 07 - 下一步行动：先完成口径、台账与服务闭环

- **Audience move**: 从识别问题，转为形成可执行的复盘改进顺序。
- **Layout**: 三行行动表，按优先级从上到下排列，每行连接“缺口”与“预期产出”。
- **Title**: 下一步行动：先完成口径、台账与服务闭环
- **Core message**: 下一步以范围可确认、运行可追溯、事项可闭环为目标，先补齐数据再开展常态化复盘。
- **Content**: 行动 1：对齐本次月度复盘区间与服务范围，解决阶段报告与月度会议口径不一致，产出经双方确认的本期范围、系统清单与服务事项清单。行动 2：补齐运行台账与基础设施记录，解决服务器/数据库、巡检、监控和事件证据缺失，产出资产清单、巡检记录、监控/日志摘要、事件闭环记录。行动 3：核验需求与工单闭环，解决需求数量与明细不一致、工单统计未填，产出经确认的需求/工单台账、完成或验收状态及工时口径。责任人和完成日期待双方确认。
- **Native-ready**: no

#### Slide 08 - 需要客户协同：确认口径并补齐复盘输入

- **Audience move**: 从泛化的“请客户配合”，转为明确客户确认项如何解锁可验证的运维与交付输出。
- **Layout**: 四行协同矩阵，左列为建议客户确认项，中列说明目的，右列强调可形成的输出；顶部以“建议项，不是原报告已填写待办”作边界标识。
- **Title**: 需要客户协同：确认口径并补齐复盘输入
- **Core message**: 原始报告没有已填写的客户协同事项；为形成可验证的月度复盘结论，建议优先确认四类关键输入。
- **Content**: 协同项 1：确认本次复盘的单月区间及纳入服务范围，目的为对齐阶段报告与月度会议边界，输出月度复盘口径说明。协同项 2：提供或确认服务器、数据库和应用资产清单及可用运行记录，目的为补齐基础设施与运行证据，输出系统运行与巡检摘要。协同项 3：确认本期事件、问题、工单的统计口径及是否存在漏记，目的为建立风险与问题闭环，输出问题/事件闭环台账。协同项 4：确认需求清单、优先级与验收归属，目的为校验“3 个需求”与“1 条明细”的差异，输出需求交付与验收清单。页脚说明：具体联系人、授权流程、责任人与期限待现场确认。
- **Visualization**: 自定义“客户确认 → 可验证输出”协同矩阵；四行同等权重，突出输出的可交付性。
- **Closing impact**: “先确认口径，再形成结论”作为收口；四项协同确认直接对应下一轮可审阅的复盘输出。
- **Native-ready**: no

## X. Speaker Notes Requirements

- **Generation**: disabled
