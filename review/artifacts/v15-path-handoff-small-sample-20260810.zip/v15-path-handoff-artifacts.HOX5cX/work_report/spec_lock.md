<!-- ppt-master-schema: spec-lock/v1 -->
# Execution Lock

## canvas
- viewBox: 0 0 1280 720
- format: PPT 16:9

## communication
- primary_language: zh-CN
- audience: 客户项目负责人及交付管理层
- objective: 以已填写的报告事实完成月度复盘，并促成客户确认范围、补齐证据和协同闭环。
- core_message: 已核实记录有限，空白或模板字段不能替代运营结论，须先核验并补全证据链。
- consumption_mode: balanced

## mode
- mode: briefing

## visual_style
- visual_style: data-journalism

## colors
- background: #F7F8FA
- secondary_bg: #E9EEF3
- primary: #123B5D
- accent: #007C91
- secondary_accent: #C98500
- body_text: #1D2730
- surface: #FFFFFF
- grid: #C9D3DD
- risk: #B5473C

## typography
- font_family: Microsoft YaHei, Arial, sans-serif
- title_family: Microsoft YaHei, Arial, sans-serif
- body_family: Microsoft YaHei, Arial, sans-serif
- body: 24
- title: 42
- subtitle: 30
- annotation: 18
- footnote: 16
- data: 22

## icons
- library: none
- inventory: none

## page_rhythm
- P01: anchor
- P02: dense
- P03: dense
- P04: dense
- P05: anchor
- P06: dense
- P07: dense
- P08: anchor

## pptx_structure
- mode: flat

## forbidden
- `mask`, `<style>`, `class`, external CSS, `<foreignObject>`, `textPath`, `@font-face`, `<animate*>`, `<set>`, `<script>` / event attributes, `<iframe>`
- HTML named entities in text; write typography as raw Unicode and escape XML reserved characters
