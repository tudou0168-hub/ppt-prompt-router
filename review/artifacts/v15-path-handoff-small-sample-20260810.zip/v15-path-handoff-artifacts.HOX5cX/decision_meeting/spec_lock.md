<!-- ppt-master-schema: spec-lock/v1 -->
# Execution Lock

## canvas
- viewBox: 0 0 1280 720
- format: PPT 16:9

## communication
- primary_language: zh-Hans
- audience: 市政府专题决策会
- objective: 支撑对标浙江政务服务提升路线的审议，明确约束、真实取舍、推荐方向及后续需补齐的执行依据。
- core_message: 不推倒既有平台、不强拆存量系统、不铺摊子；以统一治理能力和高频事项优先推进。
- consumption_mode: balanced

## mode
- mode: pyramid

## visual_style
- visual_style: swiss-minimal

## colors
- background: #071A2B
- secondary_background: #102E46
- primary: #63C5DA
- accent: #F2B84B
- secondary_accent: #E36B6B
- body_text: #EEF5F8

## typography
- font_family: Microsoft YaHei, Arial, sans-serif
- title_family: Microsoft YaHei, Arial, sans-serif
- body_family: Microsoft YaHei, Arial, sans-serif
- body: 24
- title: 40
- subtitle: 20
- annotation: 16

## icons
- library: none
- inventory: none

## page_rhythm
- P05: dense
- P06: anchor
- P07: anchor
- P12: dense

## pptx_structure
- mode: flat

## forbidden
- `mask`, `<style>`, `class`, external CSS, `<foreignObject>`, `textPath`, `@font-face`, `<animate*>`, `<set>`, `<script>` / event attributes, `<iframe>`
- HTML named entities in text; write typography as raw Unicode and escape XML reserved characters
