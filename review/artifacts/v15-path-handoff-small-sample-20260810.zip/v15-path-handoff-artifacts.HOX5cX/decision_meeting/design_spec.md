<!-- ppt-master-schema: design-spec/v1 -->
# v15-decision-meeting_ppt169_20260810 - Design Spec

## I. Project Information

| Item | Value |
| --- | --- |
| Project Name | v15-decision-meeting_ppt169_20260810 |
| Canvas Format | PPT 16:9 (1280 × 720) |
| Page Count | 4 (12页审议材料中的执行样本：P05、P06、P07、P12) |
| Primary Language | zh-Hans |
| Target Audience | 市政府专题决策会；需在既有材料事实边界内判断提升路线及同步治理条件 |
| Communication Intent | 为专题决策会澄清路线约束、真实取舍、推荐方向与需拍板动作；优先避免把大拆大建误呈为一套已测算的平行方案 |
| Desired Audience Outcome | 会议能够确认渐进式增量改造的边界与治理条件，并授权补齐进入执行性决策前所需的事实清单 |
| Core Message / Ask / Action | 不推倒既有平台、不强拆存量系统、不铺摊子；以统一治理能力和高频事项优先推进，并先补齐预算、时序、责任与指标依据 |
| Delivery Context | 现场专题决策会主讲，投屏审议；会后供决策纪要与后续工作清单引用 |
| Artifact Afterlife | 会议审议留痕、后续清单编制与跨部门对齐 |
| Reading Mode | balanced |
| Content Strategy | balanced default；以已确认的12页 Plan 为语义导演稿，只执行其中P05、P06、P07、P12四页，不补写计划外事实或备选方案 |
| Design Style | 决策会议的克制、结论先行、证据可追溯的咨询式版面 |
| Formula Policy | text-only |
| AI Image Acquisition Path | not applicable |
| Generation Mode | continuous |
| Spec Refinement | disabled |
| Speaker Notes | disabled — final Stage-2 proactive policy |
| Custom Animations | disabled — final Stage-2 proactive policy |
| Narration Audio | disabled — final Stage-2 proactive policy |
| Created Date | 2026-08-10 |

## II. Canvas Specification

| Property | Value |
| --- | --- |
| Format | PPT 16:9 |
| Dimensions | 1280 × 720 |
| viewBox | `0 0 1280 720` |
| Margins | 56px outer safe margin |
| Content Area | x=56–1224; y=72–656 |

## III. Visual Theme

### Theme Style

- **Mode**: pyramid
- **Visual style**: swiss-minimal
- **Theme**: 深海军蓝底色上的“决策路径”折线母题；结论和约束用强对比色切分，避免装饰性技术感。
- **Tone**: 严谨、克制、可拍板；以深色底、浅色正文和单一暖色风险提示形成会商聚焦。

### Color Scheme

| Role | HEX | Purpose |
| --- | --- | --- |
| Background | #071A2B | 全页深色底，形成严肃的决策会场基调 |
| Secondary background | #102E46 | 分区与卡片底色 |
| Primary | #63C5DA | 推荐路线、结构线与关键事实 |
| Accent | #F2B84B | 取舍、约束与待决重点 |
| Secondary accent | #E36B6B | 风险或不可越界项 |
| Body text | #EEF5F8 | 正文与高对比阅读 |

## IV. Typography System

### Font Plan

| Role | Character (Reference) | Primary | English if non-English | Fallback tail |
| --- | --- | --- | --- | --- |
| Title | 现代无衬线、紧凑、会议型 | Microsoft YaHei | Arial | Arial, sans-serif |
| Body | 清晰、稳重、投屏易读 | Microsoft YaHei | Arial | Arial, sans-serif |

- **Title stack**: Microsoft YaHei, Arial, sans-serif
- **Body stack**: Microsoft YaHei, Arial, sans-serif

### Font Size Hierarchy

| Purpose | Anchor Size (px) |
| --- | ---: |
| Body | 24 |
| Title | 40 |
| Subtitle | 20 |
| Annotation | 16 |

## V. Layout Principles

### Page Structure

- **Header area**: 左上页码/章节锚点与两行内结论式标题；页码保留真实 Plan 编号。
- **Content area**: 每页只呈现一个决策关系，以非等宽分区、路径线或条件栈替代均分卡片墙。
- **Footer area**: 仅标注“材料依据 / 不可外推”式出处边界，不添加未经来源支持的指标。

### Spacing Specification

| Element | Current Project |
| --- | --- |
| Safe margin | 56px |
| Content block gap | 20–28px |
| Icon-text gap | 10px |

## VI. Icon Usage Specification

- **Primary bundled library**: none

| Icon Path | Suitable Scenarios |
| --- | --- |

## VIII. Image Resource List

| Filename | Dimensions | Ratio | Purpose | Type | Layout pattern | Crop Policy | Acquire Via | Status | Reference | text_policy | page_role |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

## IX. Content Outline

### Part 1: 路线约束与真实取舍

#### Slide 05 - 四项刚性约束决定了不能照搬浙江、也不能大拆大建

- **Audience move**: 从“为何不直接复制浙江或重建平台” → 接受渐进式路线是材料约束下的理性选择。
- **Layout**: 左侧一条由“约束”压向“可行原则”的纵向决策线；右侧用四个不等高证据带呈现财政与基层、存量系统、技术生态和路线约束，底部一条细出处边界。
- **Title**: 四项刚性约束决定了不能照搬浙江、也不能大拆大建
- **Core message**: 人口规模、基层层级、财政压力、存量系统和技术生态共同限定了可行路径：必须低成本、渐进式、重标准与复用。
- **Content**: 
  - 财政与基层：人口大、服务半径广、基层层级多、地区差异明显，难以持续高强度投入。
  - 存量系统：部门专网、垂直系统、区县系统并存；大拆大建会抬高重复建设、迁移、数据治理、培训和运维成本。
  - 技术生态：郑州具备一定数字产业基础，但人才、供应商、产品化与持续运维能力弱于浙江。
  - 路线约束：轻重结合、先高频后全量、先标准后智能、先复用后新建。
  - 边界提示：材料未提供高频事项清单、系统资产台账、财政上限或迁移成本，页面不形成分批、预算承诺。
- **Native shape suggestion**: 约束向可行原则收敛的粗折线，可采用连接符与圆角矩形基础形状。
- **Motion suggestion**: 主讲时先出现四项约束，再收束到路线原则；仅作叙事建议。

#### Slide 06 - 本次不存在多套真实方案：需审议的是“增量治理”与其必须接受的取舍

- **Audience move**: 从“在技术方案中二选一” → 转向“是否接受增量治理所要求的跨部门治理取舍”。
- **Layout**: 顶部放置醒目的“非多方案比较”标识；中央为一条横向天平式因果带，左端为不可取的高风险做法，中心为材料唯一可行路线，右端为必须同步承担的治理投入。
- **Title**: 本次不存在多套真实方案：需审议的是“增量治理”与其必须接受的取舍
- **Core message**: 材料只提出一条可行路线：保留存量、增量改造、优先高频事项和统一治理；代价是必须推进跨部门规则、数据与运营协同。
- **Content**:
  - 材料明确不建议：再建更大平台、一次性推倒重来；其风险包括重复建设、系统迁移、数据治理、培训和运维成本上升。
  - 材料提出的可行路线：保留“豫事办”“郑好办”和部门存量系统，实施增量改造；优先高频事项和统一治理能力。
  - 需要接受的取舍：短期不以重建换取表面统一，转而投入跨部门标准、接口、数据责任和持续运营。
  - 决策边界：大拆大建不是一套已有测算、可与推荐路线并列比较的成熟备选方案。
- **Native shape suggestion**: 两端风险与治理投入围绕中心路线的天平关系，可用细连接线、圆形节点与梯形底座组合。
- **Motion suggestion**: 先显现“非多方案比较”，再按高风险做法—推荐路线—治理取舍的逻辑展开；仅作叙事建议。

### Part 2: 推荐路线与会议拍板

#### Slide 07 - 推荐审议方向：以既有平台为底座，先形成统一治理能力再扩展服务范围

- **Audience move**: 从“新增技术清单” → 理解路线是“保留—统一—逐步纳管—按序扩展”的能力建设。
- **Layout**: 一条从左至右的四段能力路径，第一段以既有平台作底座，第二段以五项统一能力为核心，第三段以协同工具作纳管支撑，第四段以三项优先顺序作扩展闸门；101个专网互联基础以小注标出但不夸大对接深度。
- **Title**: 推荐审议方向：以既有平台为底座，先形成统一治理能力再扩展服务范围
- **Core message**: 以既有平台和存量系统为基础，在统一事项、知识、接口、数据授权和评价上做增量改造，逐步形成可持续的统一治理能力。
- **Content**:
  - 保留：省一体化平台、“豫事办”、“郑好办”及部门存量系统。
  - 统一：事项、知识、接口、数据授权、评价。
  - 逐步纳管：中台、网关、流程编排、电子证照、材料库、知识库和运营指标用于增强协同。
  - 优先顺序：先高频后全量、先标准后智能、先复用后新建。
  - 已有基础：郑州已有101个专网系统互联互通；材料同时指出其对接深度不明，不等同于流程协同或全链条闭环。
- **Native shape suggestion**: 四段连续路径，可用宽箭头、圆角矩形和连接符实现，避免以流程图暗示既定工程实施顺序。
- **Motion suggestion**: 按“保留—统一—纳管—扩展”递进呈现，让推荐路线被读成能力主线；仅作叙事建议。

#### Slide 12 - 请拍板：确认路线边界，并授权形成可执行的后续清单

- **Audience move**: 从“同意方向” → 明确本次可拍板事项与进入执行性决策前必须补齐的依据。
- **Layout**: 左侧三项建议审议确认以编号决策条呈现，右侧四类待补依据作为“确认后形成”的清单；两区之间以一条“本次拍板边界”竖线切开，底部用一句结论收口。
- **Title**: 请拍板：确认路线边界，并授权形成可执行的后续清单
- **Core message**: 本次拍板的是渐进提升方向及其治理条件；预算、时序、目标、项目和责任分工必须在后续清单补齐后再进入执行性决策。
- **Content**:
  - 建议审议确认 1：不以大拆大建为路径，保留既有平台与存量系统，实施增量改造。
  - 建议审议确认 2：按先高频后全量、先标准后智能、先复用后新建的原则推进。
  - 建议审议确认 3：将统一事项与知识、接口与数据授权、状态回传与评价、运营与基层能力作为同步条件。
  - 确认后需形成：高频事项清单；存量系统与对接深度台账；运营指标基线和目标；预算、时序、责任分工方案。
  - 决策边界：这些后续依据不是原始材料已给出的预算、工期、KPI或责任单位；如需同步批准，必须另行补充事实材料。
- **Native shape suggestion**: 三项确认与四类待补依据的双栏决策面板，可使用编号圆形、分隔线和圆角矩形。
- **Closing impact**: 会议不是批准“再建一个平台”，而是确认一条在现有约束下可持续的治理改造路线。

## X. Speaker Notes Requirements

- **Generation**: disabled
