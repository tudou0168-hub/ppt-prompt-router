<!-- ppt-master-schema: spec-lock/v1 -->
# Execution Lock

## canvas
- viewBox: 0 0 1280 720
- format: PPT 16:9

## communication
- primary_language: zh-Hans-CN
- audience: 客户业务、信息化和决策负责人
- objective: 说明第三方业务系统“免证办、全程网办”的业务与技术协同，并形成按事项确认范围、联调与验收的共同语言。
- core_message: 以事项为单位贯通认证授权、电子材料、签章、跨端传递和第三方系统办理，原案例事实不等同于本项目承诺。

## mode
- mode: briefing

## visual_style
- visual_style: blueprint

## colors
- background: #081B33
- secondary_background: #102A49
- primary: #31B6E8
- accent: #77D6B3
- secondary_accent: #F5BF5B
- body_text: #EAF4FF

## typography
- font_family: Microsoft YaHei, PingFang SC, Arial
- title_family: Microsoft YaHei, PingFang SC, Arial
- body_family: Microsoft YaHei, PingFang SC, Arial
- body: 24
- title: 42
- subtitle: 30
- annotation: 18
- footnote: 16

## icons
- library: none
- inventory: none

## page_rhythm
- P01: anchor
- P02: breathing
- P03: dense
- P04: anchor
- P05: dense
- P06: dense
- P07: anchor
- P08: dense
- P09: dense
- P10: anchor
- P11: breathing
- P12: anchor

## pptx_structure
- mode: flat

## forbidden
- `mask`, `<style>`, `class`, external CSS, `<foreignObject>`, `textPath`, `@font-face`, `<animate*>`, `<set>`, `<script>` / event attributes, `<iframe>`
- HTML named entities in text; write typography as raw Unicode and escape XML reserved characters
