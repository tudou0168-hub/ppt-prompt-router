<!-- ppt-master-schema: design-spec/v1 -->
# 五寨县“人工智能+”规划方案 - Design Spec

## I. Project Information

| Item | Value |
| --- | --- |
| Project Name | 五寨县“人工智能+”规划方案·三页语义盲测 |
| Canvas Format | PPT 16:9 (1280 × 720) |
| Page Count | 3 |
| Primary Language | zh-CN |
| Target Audience | 五寨县相关领导，需就项目深化前的事实核验、体系边界与推进机制作出判断 |
| Communication Intent | 决策沟通：先守住“规划设想不等于已建能力”的事实边界，再说明总体体系的协同逻辑，促成对现状核实、试点边界和协同推进的统筹。 |
| Desired Audience Outcome | 领导能够区分材料已明确的规划依托与尚无佐证的现状，并认可“统一支撑、场景试点、验证后扩展”的审慎推进原则。 |
| Core Message / Ask / Action | 不以拟建清单替代现状事实；先核实可复用基础和实施条件，再以统一智能底座承接业务协同并分步推进。 |
| Delivery Context | 领导汇报中的三页定向验证样页；最终服务于约15页规划方案的决策沟通。 |
| Artifact Afterlife | 用于核验视觉与语义表达是否足以支撑后续完整方案制作。 |
| Reading Mode | balanced |
| Content Strategy | balanced default：保留原始材料的建设方向与限定语，将其重组为决策所需的事实边界、体系关系和推进逻辑；不补充未经核实的五寨县现状。 |
| Design Style | 决策型蓝灰信息架构：克制、可信、以结构关系代替装饰。 |
| Formula Policy | text-only |
| AI Image Acquisition Path | not applicable |
| Generation Mode | continuous |
| Spec Refinement | disabled |
| Speaker Notes | disabled — 本次仅完成 SVG/PNG 语义盲测，不制作完整演讲稿。 |
| Custom Animations | disabled — 本次只审阅静态阅读关系。 |
| Narration Audio | disabled — workflow default。 |
| Created Date | 2026-08-10 |

## II. Canvas Specification

| Property | Value |
| --- | --- |
| Format | PPT 16:9 |
| Dimensions | 1280 × 720 |
| viewBox | `0 0 1280 720` |
| Margins | 48px outer safe margin |
| Content Area | 1184 × 600px below a compact header band |

## III. Visual Theme

### Theme Style

- **Mode**: pyramid
- **Visual style**: swiss-minimal
- **Theme**: 政务规划的“事实边界—统一支撑—分步推进”信息架构；用一条深蓝主轴和清晰层级承载结论，不以设备、AI 特效或装饰性面板替代关系。
- **Tone**: 审慎、可核验、面向决策。

### Color Scheme

| Role | HEX | Purpose |
| --- | --- | --- |
| Background | #F8FAFC | 干净、低干扰的阅读底面 |
| Secondary background | #EAF1F5 | 次级事实区、支撑带 |
| Primary | #0B3A5B | 结论、主关系和统一支撑 |
| Accent | #0F766E | 已确认、可推进的积极状态 |
| Secondary accent | #C99028 | 待核实、条件门槛与审慎提醒 |
| Body text | #18212A | 主要文字与高对比信息 |

## IV. Typography System

### Font Plan

| Role | Character (Reference) | Primary | English if non-English | Fallback tail |
| --- | --- | --- | --- | --- |
| Title | 稳定、紧凑、政务信息标题 | Noto Sans CJK SC | Arial | Microsoft YaHei, sans-serif |
| Body | 清晰、易扫读、非装饰 | Noto Sans CJK SC | Arial | Microsoft YaHei, sans-serif |

- **Title stack**: Noto Sans CJK SC, Microsoft YaHei, Arial, sans-serif
- **Body stack**: Noto Sans CJK SC, Microsoft YaHei, Arial, sans-serif

### Font Size Hierarchy

| Purpose | Anchor Size (px) |
| --- | ---: |
| Body | 24 |
| Title | 42 |
| Subtitle | 30 |
| Annotation | 18 |
| Footnote | 16 |

## V. Layout Principles

### Page Structure

- **Header area**: 每页保留页码、章节词和一句结论性标题；标题不承担全部正文。
- **Content area**: 让内容关系决定面积。事实边界用两极对照；体系用“上层业务—下层统一支撑”；路径用单条连续时序，不以同权卡片替代。
- **Footer area**: 仅保留来源限定或“待核实”性质说明，不增加装饰性页脚。

### Spacing Specification

| Element | Current Project |
| --- | --- |
| Safe margin | 48px |
| Content block gap | 24px |
| Icon-text gap | 10px |

## VI. Icon Usage Specification

- **Primary bundled library**: none

| Icon Path | Suitable Scenarios |
| --- | --- |

## VIII. Image Resource List

| Filename | Dimensions | Ratio | Purpose | Type | Layout pattern | Crop Policy | Acquire Via | Status | Reference | text_policy | page_role |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

## IX. Content Outline

### Part 1: 事实边界与实施条件

#### Slide 05 - 现有基础判断

- **Audience move**: 从“规划里写到的能力可能已具备”的模糊印象 → 明确只确认规划依托，必须通过专项摸底才可判断复用、改造、新建或暂缓。
- **Layout**: 顶部先给出一句事实边界结论；主体是非对称的“可确认的规划依托”与“尚待核实的现状底数”两极。左侧窄而稳，承载材料直接可见的依托与“拟依托10个网点”的限定；右侧更大，承载待核实对象清单。底部以一条由核实结果导向四种决策去向的细带收束。不得把四种决策去向或待核实对象制作成同等主卡片。
- **Title**: 现有基础判断：原始材料明确了服务对象与建设依托，实际底数尚待核实
- **Core message**: 可确认的是规划覆盖方向，不可确认的是五寨县既有能力；建设优先级和投资规模须以专项摸底为准。
- **Content**: 主结论：不把规划方案中的拟建能力等同于五寨县已建能力。\n\n可确认的规划依托（材料可见）：政务服务中心、基层便民服务场景、窗口服务与管理需求；材料提出“拟依托10个基层便民服务网点”开展云端服务延伸。\n\n尚待核实的现状底数（不能由规划文字推定）：大厅现有排队、叫号、预约、评价、咨询、办件及管理系统；终端与网络；数据资源与接口；现有运维与制度；10个网点的名称、事项、设备、网络、人员能力和使用情况。\n\n核实后才能决定：哪些可复用、哪些需改造、哪些应新建、哪些暂不具备条件。
- **Fact IDs**: 原始材料“虚拟云综窗”提出依托县级中心及10个基层便民服务网点；本页不将其表述为已建能力。

### Part 2: 总体体系与协同关系

#### Slide 08 - 总体体系

- **Audience move**: 从“多个AI应用清单” → 看到三类业务能力必须由同一支撑层承接，系统价值来自协同而非单点采购。
- **Layout**: 上部为一条从“服务前端”经“智能办理”到“数智管理”的业务主线：三个能力域以连续服务链而非独立卡片出现，分别呈现触达、流转、运营决策的职责。下部以跨越全宽的大型“统一智能底座”承托三域，三条明确的垂直承接线从每一业务域落入底座；底座内部仅分出“智能体管理平台（编排、监控、优化）”与“MaaS管理平台（模型、资源、评测）”两个支撑职责。底座面积、色彩和标题必须显著大于任何单一业务域，使“统一支撑→三类业务协同”成为第一阅读关系；不得把五类能力画成五张同等卡片。
- **Title**: 总体体系：以前端服务、智能办理、数智管理为业务主线，以统一智能底座支撑协同
- **Core message**: 前端服务承接群众需求，智能办理支撑事项流转，数智管理支撑运行决策；拟建的智能体管理与MaaS能力共同构成统一支撑，避免应用孤立建设。
- **Content**: 业务主线一：服务前端——预约排队、导办咨询、回访、政策宣讲；服务群众触达与引导。\n\n业务主线二：智能办理——填单、预审、惠企政策匹配、云综窗、云客服、数字工牌、云勘验；支撑事项办理提效与人工兜底。\n\n业务主线三：数智管理——数据大屏交互、智能问数；支撑运行监控、分析与决策。\n\n统一智能底座（均为拟建方向）：智能体管理平台负责应用编排、运行监控和持续优化；MaaS管理平台面向模型服务、资源统筹和评测。\n\n限定：平台间数据接口、部署形态、模型范围和安全策略待深化设计。

### Part 3: 分步推进与风险保障

#### Slide 13 - 推进路径建议

- **Audience move**: 从“一次性铺开建设清单” → 认同以条件核实和小范围验证控制风险，再按证据扩展的实施节奏。
- **Layout**: 用一条左至右、不断向前的连续推进带组织四步，而非四张等权卡片；每一步直接写明“动作 + 必须形成的成果”。第二步前设置“条件成熟”门槛，第三步以回看箭头连接第二步，强调评估不通过则回到试点优化；第四步只在通过效果、安全和运维验证后开启。底部用一条轻量风险保障线贯穿数据、安全、运维三项验证维度，并明确时间、预算、承建、验收范围尚待立项与调研确定。
- **Title**: 推进路径建议：以现状核实和场景试点为起点，分步验证后扩展
- **Core message**: 不以一次性铺开替代验证；遵循“底数核实—优先场景试点—评估优化—协同扩展”，在每个阶段以可交付成果与风险门槛决定下一步。
- **Content**: 第一步｜现状核实：摸清系统、设备、数据、事项、网点、网络安全和组织运维；成果是复用与改造边界。\n\n第二步｜优先场景试点：从规则清晰、需求集中、数据条件相对成熟的服务或办理场景中遴选试点；成果是可验证的试点方案与责任边界，具体场景待核实。\n\n第三步｜评估优化：围绕服务效率、群众体验、窗口负荷、数据质量、安全合规和运维响应评估；成果是通过、优化或止步的证据。\n\n第四步｜协同扩展：根据试点结果扩展事项、基层网点和管理应用；成果是逐步形成统一运营机制。\n\n限定：阶段时间、预算、承建方式、验收指标和上线范围均待立项及调研后确定。

## X. Speaker Notes Requirements

- **Generation**: disabled
