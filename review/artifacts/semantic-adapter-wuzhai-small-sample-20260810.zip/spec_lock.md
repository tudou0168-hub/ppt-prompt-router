<!-- ppt-master-schema: spec-lock/v1 -->
# Execution Lock

## canvas
- viewBox: 0 0 1280 720
- format: PPT 16:9

## communication
- primary_language: zh-CN
- audience: 五寨县相关领导
- objective: 让领导以事实底数而非拟建设想判断基础、体系协同与分步推进条件。
- core_message: 先核实可复用基础和实施条件，再以统一智能底座承接业务协同并分步推进。
- consumption_mode: balanced

## mode
- mode: pyramid

## visual_style
- visual_style: swiss-minimal

## colors
- background: #F8FAFC
- secondary_background: #EAF1F5
- primary: #0B3A5B
- accent: #0F766E
- secondary_accent: #C99028
- body_text: #18212A

## typography
- font_family: Noto Sans CJK SC, Microsoft YaHei, Arial, sans-serif
- title_family: Noto Sans CJK SC, Microsoft YaHei, Arial, sans-serif
- body_family: Noto Sans CJK SC, Microsoft YaHei, Arial, sans-serif
- body: 24
- title: 42
- subtitle: 30
- annotation: 18
- footnote: 16

## icons
- library: none
- inventory: none

## page_rhythm
- P05: dense
- P08: anchor
- P13: dense

## pptx_structure
- mode: flat

## forbidden
- `mask`, `<style>`, `class`, external CSS, `<foreignObject>`, `textPath`, `@font-face`, `<animate*>`, `<set>`, `<script>` / event attributes, `<iframe>`
- HTML named entities in text; write typography as raw Unicode and escape XML reserved characters
